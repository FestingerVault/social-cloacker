<?php
/*
Plugin Name: Social Cloaker
Plugin URI: https://festingervault.com
Description: The ultimate stealth plugin for redirecting normies and bots to different pages. Cloak your links like a digital ninja.
Version: 1.1.0
Author: Festinger Vault Ninjas
License: GPL2
*/

if (!defined('ABSPATH')) exit; // Exit if accessed directly

function social_cloaker_ninja_redirect() {
    if (is_admin()) return; // Don’t cloak your own admin area, duh

    $money_page_url = get_option('social_cloaker_money_url', 'https://example.com/offer');
    $safe_page_url = get_option('social_cloaker_safe_url', 'https://example.com/safe');

    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

    $is_bot = preg_match('/bot|crawl|slurp|spider/i', $ua);
    $from_social = preg_match('/facebook|instagram|t.co|twitter|linkedin|reddit/i', $ref);

    if ($from_social && !$is_bot) {
        wp_redirect($money_page_url);
        exit;
    } else {
        if (!is_page('safe-page')) {
            wp_redirect($safe_page_url);
            exit;
        }
    }
}
add_action('template_redirect', 'social_cloaker_ninja_redirect');

function social_cloaker_menu() {
    add_options_page('Social Cloaker', 'Social Cloaker', 'manage_options', 'social-cloaker-settings', 'social_cloaker_settings_page');
}
add_action('admin_menu', 'social_cloaker_menu');

function social_cloaker_settings_page() {
    if (isset($_POST['social_cloaker_save_settings'])) {
        update_option('social_cloaker_money_url', sanitize_text_field($_POST['social_cloaker_money_url']));
        update_option('social_cloaker_safe_url', sanitize_text_field($_POST['social_cloaker_safe_url']));
        echo '<div class="updated"><p>Settings saved. Ninja style!</p></div>';
    }

    $money_url = esc_attr(get_option('social_cloaker_money_url', 'https://example.com/offer'));
    $safe_url = esc_attr(get_option('social_cloaker_safe_url', 'https://example.com/safe'));

    echo '<div class="wrap"><h1>🥷 Social Cloaker Settings</h1>';
    echo '<form method="post">';
    echo '<table class="form-table">';
    echo '<tr><th scope="row"><label for="social_cloaker_money_url">Money Page URL</label></th>';
    echo '<td><input name="social_cloaker_money_url" type="text" id="social_cloaker_money_url" value="' . $money_url . '" class="regular-text"></td></tr>';
    echo '<tr><th scope="row"><label for="social_cloaker_safe_url">Safe Page URL</label></th>';
    echo '<td><input name="social_cloaker_safe_url" type="text" id="social_cloaker_safe_url" value="' . $safe_url . '" class="regular-text"></td></tr>';
    echo '</table>';
    echo '<p class="submit"><input type="submit" name="social_cloaker_save_settings" id="submit" class="button button-primary" value="Save Ninja Settings"></p>';
    echo '</form>';
    echo '<p><strong>Tip:</strong> Only weaklings edit PHP directly. Real ninjas use the dashboard.</p>';
    echo '<p>Brought to you by <a href="https://festingervault.com">Festinger Vault Ninjas</a></p>';
    echo '</div>';
}
